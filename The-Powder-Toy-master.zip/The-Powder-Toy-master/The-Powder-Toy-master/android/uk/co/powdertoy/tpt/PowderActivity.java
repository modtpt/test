package uk.co.powdertoy.tpt;

import org.libsdl.app.SDLActivity;

public class PowderActivity extends SDLActivity
{
}
