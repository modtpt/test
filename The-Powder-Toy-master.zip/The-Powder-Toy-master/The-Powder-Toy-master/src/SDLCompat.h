#include "Config.h"
#include <SDL.h>
#ifdef INCLUDE_SYSWM
# if defined(WIN)
#  include <SDL_syswm.h>
# endif // WIN
#endif // INCLUDE_SYSWM
