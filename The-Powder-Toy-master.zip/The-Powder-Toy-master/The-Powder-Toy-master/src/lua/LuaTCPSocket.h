#pragma once

#include "Config.h"

#include "LuaCompat.h"

namespace LuaTCPSocket
{
	void Open(lua_State *l);
}
