#pragma once

#include "graphics/Pixel.h"
#include "common/String.h"

struct BuiltinGOL
{
	String name;
	int oldtype;
	int ruleset;
	pixel colour, colour2;
	int goltype;
	String description;
};
