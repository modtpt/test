#define LUASCRIPT 256

#define IDI_ICON 101
#define IDI_DOC_ICON 102

